package com.example.viraljani.lockapp;

/**
 * Created by VIRAL JANI on 8/16/2017.
 */

public class LockApp {

    private int id;
    private String appName;
    private int lock;

    public LockApp(int id, String appName, int lock){
        this.id = id;
        this.appName = appName;
        this.lock = lock;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getLock() {
        return lock;
    }

    public void setLock(int lock) {
        this.lock = lock;
    }
}
