package com.example.viraljani.lockapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by VIRAL JANI on 8/16/2017.
 */

public class DBHelper extends SQLiteOpenHelper {

    // Constants which define table details
    private static final String DATABASE_NAME = "LockApp.db";
    private static final String TABLE_NAME = "LockApps";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_APPNAME = "appname";
    private static final String COLUMN_LOCK = "lock";

    // Constants which store running app detail
    private static final String APP_TABLE_NAME = "RunningApp";
    private static final String APP_COLUMN_APPNAME = "appname";

    // Constants which PIN detail
    private static final String PIN_TABLE_NAME = "PINTable";
    private static final String PIN_COLUMN_APPNAME = "PIN";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    // create table
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_APPNAME + " TEXT NOT NULL, " +
                COLUMN_LOCK + " INTEGER NOT NULL" +
                ");");

        sqLiteDatabase.execSQL("CREATE TABLE " + APP_TABLE_NAME + "(" +
                APP_COLUMN_APPNAME + " TEXT NOT NULL " +
                ");");

        sqLiteDatabase.execSQL("CREATE TABLE " + PIN_TABLE_NAME + "(" +
                PIN_COLUMN_APPNAME + " TEXT NOT NULL " +
                ");");
    }

    //  upgrade database
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS LockApps");
        onCreate(sqLiteDatabase);
    }

    // Insert new entry
    public boolean insertApp(String AppName) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_APPNAME,AppName);
        contentValues.put(COLUMN_LOCK,0);
        database.insert(TABLE_NAME,null,contentValues);
        return true;
    }

    // Insert new running APP
    public boolean insertRunningApp(String AppName) {
        SQLiteDatabase database = this.getWritableDatabase();
        database.execSQL("DELETE FROM "+APP_TABLE_NAME);
        ContentValues contentValues = new ContentValues();
        contentValues.put(APP_COLUMN_APPNAME,AppName);
        database.insert(APP_TABLE_NAME,null,contentValues);
        Log.e("Inserted","Success");
        return true;
    }

    // Get running apps
    public String getRunningAppName(){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor data = database.rawQuery("SELECT "+APP_COLUMN_APPNAME+" FROM "+APP_TABLE_NAME+";",null);
        data.moveToFirst();
        String appName = "";
        while(!data.isAfterLast()){
            appName = data.getString(data.getColumnIndex(APP_COLUMN_APPNAME));
            data.moveToNext();
        }
        return appName;
    }

    // Get details apps
    public Cursor getData(){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor data = database.rawQuery("SELECT "+COLUMN_ID+","+COLUMN_APPNAME+","+COLUMN_LOCK+" FROM "+TABLE_NAME+";",null);
        return data;
    }

    // update detail of lock for app
    public boolean updateAppLock(int id,int lock){
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_LOCK,lock);
        database.update(TABLE_NAME,contentValues,COLUMN_ID+" = ?",new String[]{id+""});
        Log.e("Updated","App");
        return true;
    }

    public ArrayList<LockApp> getAllApps(){
        ArrayList<LockApp> lockApps = new ArrayList<LockApp>();

        // get details from table
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM "+TABLE_NAME,null);
        cursor.moveToFirst();

        // feed details into arraylist
        while(!cursor.isAfterLast()){
            lockApps.add(new LockApp(
                    cursor.getInt(cursor.getColumnIndex(COLUMN_ID)),
                    cursor.getString(cursor.getColumnIndex(COLUMN_APPNAME)) ,
                    cursor.getInt(cursor.getColumnIndex(COLUMN_LOCK)))
            );
            cursor.moveToNext();
        }

        // return arraylist
        return lockApps;
    }
}
