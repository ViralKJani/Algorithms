package com.example.viraljani.lockapp;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.SystemClock;
import android.support.annotation.Nullable;
import android.support.v7.widget.ActivityChooserView;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Exchanger;

/**
 * Created by VIRAL JANI on 8/16/2017.
 */

public class LockService extends Service {

    private static BroadcastReceiver tickReceiver;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    ArrayList<LockApp> arrayList;
    @Override
    public int onStartCommand(final Intent intent, int flags, int startId) {

        DBHelper dbHelper = new DBHelper(getApplicationContext());
        ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningProcesses = am.getRunningAppProcesses();
        PackageManager pm = this.getPackageManager();
        int count = 0;
        for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses ) {
            if(count != 0){
                break;
            }
            if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND && count == 0 ) {

                try{
                    CharSequence c = pm.getApplicationLabel(pm.getApplicationInfo(processInfo.processName,PackageManager.GET_META_DATA));
                    arrayList = dbHelper.getAllApps();
                    for(int i = 0;i<arrayList.size();i++){
                        if(arrayList.get(i).getAppName().equals(c.toString()) && arrayList.get(i).getLock() == 1 &&
                                !dbHelper.getRunningAppName().equals(c.toString()) && !c.toString().equals("LockApp") ){
                            Intent intent1 = new Intent(getBaseContext(),PIN.class);
                            intent1.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent1.putExtra("RunningAppName",c.toString());
                            startActivity(intent1);
                        }
                    }
                }
                catch(Exception e){

                }

                count = 1;
                break;
            }
        }
        return START_STICKY;
    }


    @Override
    public void onTaskRemoved(Intent rootIntent) {

        Calendar cal = Calendar.getInstance();

        Intent intent = new Intent(this, LockService.class);
        PendingIntent pintent = PendingIntent.getService(this, 0, intent, 0);

        AlarmManager alarm = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        // Start every minute
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), 1000, pintent);

    }

    @Override
    public void onDestroy() {
        Intent service = new Intent(getBaseContext(), LockService.class);
        startService(service);
    }
}
