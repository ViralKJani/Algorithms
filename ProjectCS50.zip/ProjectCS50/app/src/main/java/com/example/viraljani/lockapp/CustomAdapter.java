package com.example.viraljani.lockapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by VIRAL JANI on 8/17/2017.
 */

public class CustomAdapter extends ArrayAdapter {

    private ArrayList dataSet;
    Context mContext;

    public static class ViewHolder{
        TextView appName;
        CheckBox checkBox;
    }

    public CustomAdapter(ArrayList dataSet,Context context){
        super(context,R.layout.row_item,dataSet);
        this.dataSet = dataSet;
        mContext = context;
    }

    @Override
    public int getCount() {
        return dataSet.size();
    }

    @Nullable
    @Override
    public Object getItem(int position) {
        return dataSet.get(position);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;
        final View result;

        if(convertView == null){
            viewHolder = new ViewHolder();
            convertView = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item,parent,false);
            viewHolder.appName = (TextView) convertView.findViewById(R.id.tvName);
            viewHolder.checkBox = (CheckBox) convertView.findViewById(R.id.checkBox);

            result = convertView;
            convertView.setTag(viewHolder);
        }
        else{
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }

        LockApp lockApp = (LockApp) getItem(position);
        viewHolder.appName.setText(lockApp.getAppName());
        if(lockApp.getLock() == 0){
            viewHolder.checkBox.setChecked(false);
        }
        else{
            viewHolder.checkBox.setChecked(true);
        }


        return result;
    }
}
