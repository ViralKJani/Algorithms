package com.example.viraljani.lockapp;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class PIN extends AppCompatActivity {

    EditText edtPIN;
    Button btnOK;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        final DBHelper dbHelper = new DBHelper(PIN.this);
        edtPIN = (EditText) findViewById(R.id.edtPIN);

        btnOK = (Button) findViewById(R.id.btnPIN);
        btnOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(PIN.this,edtPIN.getText().toString(),Toast.LENGTH_SHORT).show();
                if(edtPIN.getText().toString().equals("1234")){
                    dbHelper.insertRunningApp(getIntent().getStringExtra("RunningAppName"));
                    finish();
                }
                else{
                    edtPIN.setError("Wrong PIN");
                }
            }
        });




    }

}
