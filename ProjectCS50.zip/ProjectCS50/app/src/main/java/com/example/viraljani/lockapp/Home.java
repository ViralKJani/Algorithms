package com.example.viraljani.lockapp;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

public class Home extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        dbHelper = new DBHelper(this);
        ArrayList<LockApp> lockApps = dbHelper.getAllApps();

        HashMap<String,Integer> appMap = new HashMap<String, Integer>();
        for(int i = 0;i<lockApps.size();i++){
            Log.e("obtained from DB",lockApps.get(i).getAppName());
            appMap.put(lockApps.get(i).getAppName(),lockApps.get(i).getLock());
        }

        //get a list of installed apps.
        final PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        // create lists for locked and unlocked apps
        ArrayList<String> unlockedApps = new ArrayList<String>();
        ArrayList<String> lockedApps = new ArrayList<String>();

        // populate locked and unlocked apps lists
        for (ApplicationInfo packageInfo : packages) {

            // get only installed apps excepts system applications
            if((packageInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 1){

                // get application name
                String installedAppName = packageInfo.loadLabel(pm).toString();

                // if app is not in database add an entry for newly installed app else fill in appropriate list
                if(!appMap.containsKey(installedAppName)){

                    // add an entry and show in unlocked apps
                    dbHelper.insertApp(installedAppName);
                    unlockedApps.add(installedAppName);
                }
                else{

                    if(appMap.get(installedAppName) == 0 ) {
                        unlockedApps.add(installedAppName);
                    }
                    else{
                        Log.e("Locked app",installedAppName);
                        lockedApps.add(installedAppName);
                    }

                }

            }

        }

        // Fill in list of app names in string array
        String[] unlockedAppNames = new String[unlockedApps.size()];
        String[] lockedAppNames = new String [lockedApps.size()];
        for(int i = 0;i<unlockedApps.size();i++){
            unlockedAppNames[i] = unlockedApps.get(i);
        }
        for(int i = 0;i<lockedApps.size();i++){
            Log.e("In loop","locked app is "+lockedApps.get(i));
            lockedAppNames[i] = lockedApps.get(i);
        }

        // create adapter for list view
        ArrayAdapter unlockedAppAdapter = new ArrayAdapter<String>(this, R.layout.activity_listview, unlockedAppNames);
        ArrayAdapter lockedAppAdapter = new ArrayAdapter<String>(this, R.layout.activity_listview, lockedAppNames);

        // get list view and set app names
        ListView lvUnlockedApp = (ListView) findViewById(R.id.lvHomeRecommended);
        ListView lvLockedApp = (ListView) findViewById(R.id.lvHomeLockedApps);
        lvUnlockedApp.setAdapter(unlockedAppAdapter);
        lvLockedApp.setAdapter(lockedAppAdapter);



        Calendar cal = Calendar.getInstance();

        Intent intent = new Intent(this, LockService.class);
        PendingIntent pintent = PendingIntent.getService(this, 0, intent, 0);

        AlarmManager alarm = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        // Start every minute
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), 1000, pintent);




        // get lock apps button
        Button btnLockApps = (Button) findViewById(R.id.button);

        btnLockApps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent lockAppsIntent = new Intent(Home.this,ModifyLocks.class);
                startActivity(lockAppsIntent);
                finish();
            }
        });




    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
