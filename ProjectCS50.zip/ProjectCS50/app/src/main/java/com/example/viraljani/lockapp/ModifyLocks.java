package com.example.viraljani.lockapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.concurrent.locks.Lock;

public class ModifyLocks extends AppCompatActivity {

    DBHelper dbHelper;
    Button btnSaveChanges;
    private CustomAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_locks);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        ListView lstModifyLocks = (ListView) findViewById(R.id.lvModifyLocks);
        dbHelper = new DBHelper(ModifyLocks.this);
        final ArrayList<LockApp> arrayList = dbHelper.getAllApps();
        final int[] ids = new int[arrayList.size()];
        final int[] locks = new int[arrayList.size()];
        for(int i = 0;i<arrayList.size();i++){
            ids[i] = arrayList.get(i).getId();
            locks[i] = arrayList.get(i).getLock();
        }

        btnSaveChanges = (Button) findViewById(R.id.btnModifyLock);
        btnSaveChanges.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(ModifyLocks.this,"Saved Changes",Toast.LENGTH_SHORT).show();
                onBackPressed();
            }
        });

        adapter = new CustomAdapter(arrayList,getApplicationContext());
        lstModifyLocks.setAdapter(adapter);
        lstModifyLocks.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View view, int position, long id) {
                LockApp lockApp = arrayList.get(position);

                if(lockApp.getLock() == 0){
                    dbHelper.updateAppLock(lockApp.getId(),1);
                    lockApp.setLock(1);
                    locks[position] = 1;
                }
                else{
                    dbHelper.updateAppLock(lockApp.getId(),0);
                    lockApp.setLock(0);
                    locks[position] = 0;
                }
                adapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onBackPressed() {

        Intent homeIntent = new Intent(ModifyLocks.this,Home.class);
        startActivity(homeIntent);
        finish();

        super.onBackPressed();
    }
}
